<?php
// Conexión a la base de datos
$conn = mysqli_connect("localhost", "root", "", "adb_database");

if (!$conn) {
    die("Error en la conexión a la base de datos: " . mysqli_connect_error());
}

$message = ""; // Variable para almacenar el mensaje

// Verificar que los datos han sido enviados
if (isset($_POST['name']) && isset($_POST['password'])) {
    $usu = $_POST['name'];
    $pass = $_POST['password'];

    // Consulta SQL
    $query = "SELECT * FROM table_adb WHERE name='" . mysqli_real_escape_string($conn, $usu) . "' AND password='" . mysqli_real_escape_string($conn, $pass) . "'";
    $result = mysqli_query($conn, $query);

    // Comprobar el resultado
    if ($result) {
        $cont = mysqli_num_rows($result);
        if ($cont == 1) {
            $message = "<div class='success'>Usuario correcto.</div>";
        } else {
            $message = "<div class='error'>No se encontró este usuario o faltan completar campos.</div>";
        }
    } else {
        $message = "<div class='error'>Error en la consulta: " . mysqli_error($conn) . "</div>";
    }
}

// Cerrar la conexión
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado de Inicio de Sesión</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Questrial&display=swap" rel="stylesheet">

    <style>
        * {
    font-family: "Questrial", sans-serif;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    background-color: #181818;
    scroll-behavior: smooth;
}

body {
    background-color: #181818;
    color: white;
    margin: 30px;
}

#logo {
    display: flex;
    align-items: center;
}

#logo img{
    width: 50px;
    height: 50px;

    margin-right: 10px;
}

#botones ul {
    list-style-type: none;
    display: flex;
    align-items: center;
}

#botones ul li {
    position: relative;
}

#botones ul li a{
    display: block;
    padding: 5px;

    margin-left: 10px;
}

#botones img {
    filter: invert(100%);
}

header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

#botones{
    cursor: pointer;
    transition: 0.3s;
}

.success {
    color: #4CAF50; /* Verde para éxito */
    font-weight: bold;
    margin: 20px 0;
    }

.error {
    color: #f44336; /* Rojo para error */
    font-weight: bold;
    margin: 20px 0;
}

.bodyalert{
    margin-top: 20px
}
</style>
</head>

<header>
<div id="logo">
            <img src="../img\logo\logopositivo.png" alt="logo">
            <h2>Academia<br>de Bomberos</h2>
        </div>
        
        <div id="botones">
            <ul>
                <li id="inicio">
                    <a href="../HTML\index.html"><img src="../img\icons\home.png" alt="Inicio"></a>
                </li>

                
                <li>
                    <a href="../HTML\emergencias.html"><img src="../img\icons\fire.png" alt="Fire"></a>
                </li>
                <li>
                    <a href="../HTML\rcp.html"><img src="../img\icons\heart.png" alt="RCP"></a>
                </li>

                <li>
                    <a href="../LOGIN\login.html"><img src="../img\icons\login.png" alt="login" id="loginicon"></a>
                </li>
            </ul>
        </div>
    </header>

<body>
    <div class="bodyalert">
    <h1>Resultado del Login</h1>
    <?php echo $message; // Mostrar el mensaje ?>
    </div>
</body>
</html>